#!/bin/bash


xrandr --output DP1 --mode 1280x1024 --noprimary --right-of DP-0 &
feh --bg-scale ~/Pictures/Wallpapers/wp6889832.jpg &
picom --experimental-backends -b &
